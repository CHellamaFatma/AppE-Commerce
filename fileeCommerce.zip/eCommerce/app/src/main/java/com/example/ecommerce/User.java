package com.example.ecommerce;

public class User {
    public String fullname , adress , email;
    public User(){

    }
    public User(String fullname , String adress,String email){
        this.fullname = fullname ;
        this.adress = adress;
        this.email= email;
    }
}
