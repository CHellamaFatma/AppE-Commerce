package com.example.ecommerce;

public class Upload {
    private String name;
    private String imageUrl;
    public Upload(){

    }
    public Upload(String name ,String imageUrl){
        if(name.trim().equals("")){
            name = "No Name";
        }
        name = name ;
        imageUrl = imageUrl;
    }
     public String getName(){
        return name;
     }
    public void setName(String imageUrl){
        name =name;
    }


    public String getImageUrl(){
        return imageUrl;
    }
    public void setImageUrl(String imageUrl){
        imageUrl = imageUrl;
    }
}
