package com.example.ecommerce;

import android.widget.EditText;

public class Product {
    public String nomprod , isbn , discrpyion;
    public Product(EditText nomprod, EditText isbn, EditText discrpyion){

    }
    public Product(String nomprod , String isbn,String discrpyion){
        this.nomprod = nomprod ;
        this.isbn = isbn;
        this.discrpyion= discrpyion;
    }
}
